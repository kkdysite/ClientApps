const { app, BrowserWindow } = require('electron')

const electron = require('electron')
/*获取electron窗体的菜单栏*/
const Menu = electron.Menu
/*隐藏electron创听的菜单栏*/
Menu.setApplicationMenu(null)

function createWindow () {   
  // 创建浏览器窗口
  const win = new BrowserWindow({
    width: 500,
    height: 800,
    maxWidth: 600,
    maxHeight: 800,
    minWidth: 300,
    minHeight: 260,
    maximizable:false,
    minimizable:true,
    fullscreenable:false,
    resizable:true,
    show: false, // 先隐藏
    webPreferences: {
      nodeIntegration: true
    }
    
  })
  
  



  var serv1="http://app.kkdy.website/"; //服务器1的地址
  var serv2="http://app.vipdianying.site/"; //服务器2
  var serv_file1bit="serv1bit.txt?"+Math.random(); //通过一个1字节的文件检查是否可以连接
  var webappver="?v=web-mac-202008"; //定义版本号

  var request = require('request');
  request(serv1+serv_file1bit, function (error, response, body) {
    if (!error && response.statusCode == 200) { 
      win.loadURL(serv1+webappver); //打开服务器1
    }else{
      //检测服务器2
      request(serv2+serv_file1bit, function (error, response, body) {
        if (!error && response.statusCode == 200) {
          win.loadURL(serv2+webappver); //打开服务器2
        }else{
          win.loadFile("index.html"); //打开错误提示页
        }
      });
    }
  });


  win.on('ready-to-show', function () {
    win.show() // 初始化后再显示
  })

  //win.loadFile("index.html");
    // 打开开发者工具
 // win.webContents.openDevTools()


}

// Electron会在初始化完成并且准备好创建浏览器窗口时调用这个方法
// 部分 API 在 ready 事件触发后才能使用。
app.whenReady().then(createWindow)

//当所有窗口都被关闭后退出
app.on('window-all-closed', () => {
  // 在 macOS 上，除非用户用 Cmd + Q 确定地退出，
  // 否则绝大部分应用及其菜单栏会保持激活。
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

app.on('activate', () => {
  // 在macOS上，当单击dock图标并且没有其他窗口打开时，
  // 通常在应用程序中重新创建一个窗口。
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow()
  }
})
